# ABC Shop: Frontend (Week 4), Milestones 1–3

The React user module for the ABC Shopping API built in Weeks 2 and 3.
This version covers **Milestone 1** (Register & Login), **Milestone 2** (product
listing & search), and **Milestone 3** (cart management). Checkout and order history
(Milestones 4–5) show a placeholder page for now.

**Stack:** React (JSX) + Vite, React Router, Bootstrap 5 + Bootstrap Icons, PropTypes, Vitest.

## 1. Setup

You need **Node.js 18+** and the backend running (`docker compose up -d --build` in the
backend folder), with CORS allowing `http://localhost:5173` (no slash at the end).

```powershell
cd frontend
npm install
npm install react-router-dom bootstrap bootstrap-icons prop-types
npm install -D vitest
copy .env.example .env
npm run dev
```

Open http://localhost:5173.

To run the tests, add this line to the `"scripts"` section of `package.json`,
then run `npm test`:

```json
"test": "vitest run"
```

### Test accounts (from the backend seed data)

| Email | Password | Role |
|---|---|---|
| rudra@abcshop.com | rudra1234 | customer |
| shubhi@abcshop.com | shubhi1234 | admin |
| jiya@abcshop.com | jiya1234 | support |

## 2. Folder structure

```
src/
├── main.jsx                  Starts the app (Router, AuthProvider, CartProvider)
├── App.jsx                   Layout (Header / Main / Footer) and all routes
├── index.css                 A few custom styles (the rest is Bootstrap)
├── components/
│   ├── layout/               Header, Menu, Footer
│   ├── common/               FormInput, AlertMessage, Loader, ProtectedRoute
│   ├── products/             SearchBar, ProductCard, ProductImage
│   └── cart/                 CartItemRow
├── context/                  AuthContext (who is logged in), CartContext (cart count)
├── hooks/useForm.js          Reusable form state + validation
├── pages/                    One file per page
├── services/                 All API calls (one file per backend area)
└── utils/                    validators (+ tests), price formatting
```

**How the layers talk:** pages → services → `apiClient.js` → FastAPI router →
service → repository → database. Pages never call `fetch` directly.

## 3. Which backend endpoints each page uses

| Page | Endpoints |
|---|---|
| Register | `POST /api/users/register` |
| Login | `POST /api/auth/login`, then `GET /api/users/me` |
| Home | `GET /api/categories` |
| Products | `GET /api/categories`, `GET /api/products/search?name=&category=`, `POST /api/cart/add` |
| Product details | `GET /api/products/{id}`, `POST /api/cart/add` |
| Cart | `GET /api/cart`, `GET /api/cart/summary`, `GET /api/products` (stock), `PUT /api/cart/update/{id}`, `DELETE /api/cart/remove/{id}` |
| Header badge | `GET /api/cart/summary` |

## 4. Milestones

| Milestone | What was built |
|---|---|
| 1. Registration & Login | Forms with all validations, Register/Login enabled only when valid, disabled while sending, server errors shown, Reset button, JWT saved, logout, protected pages |
| 2. Product listing & search | Product card grid, search by name as you type, category dropdown, "Out of Stock" handling, product details page |
| 3. Cart management | Add to cart, view cart, update quantity (validated against stock), remove, automatic total, Checkout enabled only when the cart isn't empty, cart badge in the header |

## 5. Validation rules

| Field | Rules |
|---|---|
| Name | Required, 6–25 characters, letters and spaces only |
| Email | Required, valid format, max 50 characters, unique (checked by the backend: 409) |
| Mobile | Required, exactly 10 digits (the backend requires it) |
| Password (register) | 8–25 characters, at least one uppercase letter, lowercase letter, number, and special character |
| Password (login) | Required |
| Cart quantity | Whole number, at least 1, not more than the available stock |

## 6. Design decisions

- **JSX instead of TypeScript:** data types are checked with **PropTypes** and documented with **JSDoc**.
- **Search** waits 300 ms after the user stops typing before calling the API ("debouncing").
- **Stock in the cart:** cart items don't include stock, so the Cart page reads it from
  `GET /api/products`. The backend checks stock again on every update.
- **Login state:** the JWT is kept in `localStorage`. If a protected request returns 401
  (token expired after 30 minutes), the app logs the user out and protected pages send
  them to Login, then back to the page they wanted.
- **Product pictures:** the seeded `product_url` values are web pages, not images, so a
  category icon is shown instead.

## 7. Manual test checklist

**Milestone 1**
1. Register with invalid values → each field shows its message; Register stays disabled.
2. Reset → all fields blank.
3. Register with `rudra@abcshop.com` → "Email is already Registered." from the server.
4. Register a new user → redirected to Login with a green success message.
5. Wrong password → "Invalid email or password."
6. Log in → your name, cart icon, and Logout appear in the header.
7. Logged out, open `/cart` → sent to Login; after logging in you come back to the cart.

**Milestone 2**
8. Type "jeans" → the list filters while typing. Pick a category → only that category shows.
9. A search with no matches → "No products match your search."
10. A product with stock 0 → "Out of Stock" button, disabled.
11. Click a product name → details page with a quantity box.

**Milestone 3**
12. Add to cart → the header badge number goes up.
13. Cart quantity 0, -1, 1.5, or more than the stock → error shown, Update disabled.
14. Update or Remove → the total changes immediately.
15. Empty cart → "Your cart is empty." and no Checkout button.
16. `npm test` → all validator tests pass.
