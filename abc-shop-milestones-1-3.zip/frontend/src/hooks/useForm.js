import { useState } from "react";

/**
 * A small reusable hook for forms (used by Register and Login).
 * It keeps the field values, works out the errors, and remembers which
 * fields the user has "touched" so we don't show errors before they type.
 *
 * @param {Record<string, string>} initialValues - e.g. { email: "", password: "" }
 * @param {(values: Record<string, string>) => Record<string, string>} validate
 *        - returns an error message per field ("" = no error)
 */
export function useForm(initialValues, validate) {
  const [values, setValues] = useState(initialValues);
  const [touched, setTouched] = useState({});

  // Errors are calculated from the values on every render, so they're always up to date
  const errors = validate(values);
  const isValid = Object.values(errors).every((message) => message === "");

  // Runs on every key press: copy the old values and change just this field
  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((previous) => ({ ...previous, [name]: value }));
  };

  // Runs when the user leaves a field: from now on, show its error
  const handleBlur = (event) => {
    const { name } = event.target;
    setTouched((previous) => ({ ...previous, [name]: true }));
  };

  // Mark every field as touched (used on submit, so all errors show)
  const touchAll = () => {
    const allTouched = {};
    Object.keys(initialValues).forEach((name) => {
      allTouched[name] = true;
    });
    setTouched(allTouched);
  };

  // Reset button: every field back to blank, no errors showing
  const reset = () => {
    setValues(initialValues);
    setTouched({});
  };

  // The error to show under a field (only after it's been touched)
  const errorFor = (name) => (touched[name] ? errors[name] : "");

  return { values, isValid, handleChange, handleBlur, touchAll, reset, errorFor };
}
