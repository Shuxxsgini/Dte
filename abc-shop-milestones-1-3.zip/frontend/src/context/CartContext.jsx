import { createContext, useCallback, useContext, useEffect, useState } from "react";
import PropTypes from "prop-types";

import { getCartSummary } from "../services/cartService.js";
import { useAuth } from "./AuthContext.jsx";

// Shares the number of items in the cart, so the header badge can show it
// and any page can refresh it after adding or removing items.
const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { isLoggedIn } = useAuth();
  const [count, setCount] = useState(0);

  // Ask the backend for the cart totals and keep the total quantity
  const refreshCartCount = useCallback(async () => {
    if (!isLoggedIn) return;
    try {
      const summary = await getCartSummary();
      setCount(summary.total_quantity);
    } catch {
      setCount(0); // the badge is only a hint; never break the page for it
    }
  }, [isLoggedIn]);

  // Load the count whenever the user logs in
  useEffect(() => {
    refreshCartCount();
  }, [refreshCartCount]);

  // Logged-out users always see 0
  const value = { cartCount: isLoggedIn ? count : 0, refreshCartCount };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

CartProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

// Shortcut: const { cartCount, refreshCartCount } = useCart();
// eslint-disable-next-line react-refresh/only-export-components
export const useCart = () => useContext(CartContext);
