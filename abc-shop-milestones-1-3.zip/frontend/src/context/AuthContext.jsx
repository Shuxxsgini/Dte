import { createContext, useContext, useEffect, useState } from "react";
import PropTypes from "prop-types";

import { getCurrentUser, loginUser } from "../services/authService.js";
import { clearToken, getToken, saveToken } from "../services/tokenStorage.js";
import { SESSION_EXPIRED_EVENT } from "../services/apiClient.js";

// A "context" shares data with every component without passing props down
// through each level. This one shares who is logged in.
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // The logged-in user ({ user_id, name, email, mobile, role }), or null
  const [user, setUser] = useState(null);

  // true while we check a saved token on startup (only if there is one)
  const [loading, setLoading] = useState(() => Boolean(getToken()));

  // On startup: if a token was saved earlier, ask the backend who it belongs to
  useEffect(() => {
    if (!getToken()) return;

    getCurrentUser()
      .then((me) => setUser(me))
      .catch(() => {
        clearToken(); // token expired or invalid: forget it
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  // If any request gets a 401 (token expired), apiClient fires this event → log out
  useEffect(() => {
    const handleSessionExpired = () => setUser(null);
    window.addEventListener(SESSION_EXPIRED_EVENT, handleSessionExpired);
    // Cleanup: stop listening when this component goes away
    return () => window.removeEventListener(SESSION_EXPIRED_EVENT, handleSessionExpired);
  }, []);

  // Log in: get a token, save it, then load the user's details
  const login = async (email, password) => {
    const { access_token: accessToken } = await loginUser(email, password);
    saveToken(accessToken);
    const me = await getCurrentUser();
    setUser(me);
    return me;
  };

  // Log out: forget the token and the user
  const logout = () => {
    clearToken();
    setUser(null);
  };

  const value = { user, loading, isLoggedIn: user !== null, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

// Shortcut so components can write: const { user, login } = useAuth();
// eslint-disable-next-line react-refresh/only-export-components
export const useAuth = () => useContext(AuthContext);
