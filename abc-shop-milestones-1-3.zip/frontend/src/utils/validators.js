// All form validation rules in one place.
// Each function returns an error message, or "" (empty) when the value is valid.
// Rules come from the Week 4 document, plus the backend's limits
// (name max 25, email max 50, password max 25, mobile = 10 digits).

const NAME_PATTERN = /^[A-Za-z ]+$/; // letters and spaces only
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // something@something.something
const MOBILE_PATTERN = /^\d{10}$/; // exactly 10 digits

/** Name: required, 6–25 characters, letters (and spaces between words) only */
export function validateName(name) {
  const value = name.trim();
  if (!value) return "Name is required.";
  if (!NAME_PATTERN.test(value)) return "Name can contain letters and spaces only.";
  if (value.length < 6) return "Name must be at least 6 characters.";
  if (value.length > 25) return "Name must be 25 characters or fewer.";
  return "";
}

/** Email: required, valid format, at most 50 characters */
export function validateEmail(email) {
  const value = email.trim();
  if (!value) return "Email is required.";
  if (!EMAIL_PATTERN.test(value)) return "Enter a valid email, like name@example.com.";
  if (value.length > 50) return "Email must be 50 characters or fewer.";
  return "";
}

/** Mobile: required, exactly 10 digits (the backend needs it) */
export function validateMobile(mobile) {
  const value = mobile.trim();
  if (!value) return "Mobile number is required.";
  if (!MOBILE_PATTERN.test(value)) return "Mobile number must be exactly 10 digits.";
  return "";
}

/** Password for registration: 8–25 characters with upper, lower, number, and special character */
export function validatePassword(password) {
  if (!password) return "Password is required.";
  if (password.length < 8) return "Password must be at least 8 characters.";
  if (password.length > 25) return "Password must be 25 characters or fewer.";
  if (!/[A-Z]/.test(password)) return "Add at least one uppercase letter.";
  if (!/[a-z]/.test(password)) return "Add at least one lowercase letter.";
  if (!/[0-9]/.test(password)) return "Add at least one number.";
  if (!/[^A-Za-z0-9]/.test(password)) return "Add at least one special character, like @ or #.";
  return "";
}

/** Any required field (used for the login password) */
export function validateRequired(value, fieldLabel) {
  return value.trim() ? "" : `${fieldLabel} is required.`;
}

/**
 * Quantity: a whole number from 1 up to the stock available.
 * @param {string|number} value - what the user typed
 * @param {number} maxStock - available quantity of the product
 */
export function validateQuantity(value, maxStock) {
  const text = String(value).trim();
  if (!text) return "Quantity is required.";
  if (!/^\d+$/.test(text) || Number(text) < 1) return "Enter a whole number of 1 or more.";
  if (Number(text) > maxStock) return `Only ${maxStock} in stock.`;
  return "";
}

/** All register fields at once → { name, email, mobile, password } error messages */
export const validateRegisterForm = (values) => ({
  name: validateName(values.name),
  email: validateEmail(values.email),
  mobile: validateMobile(values.mobile),
  password: validatePassword(values.password),
});

/** All login fields at once → { email, password } error messages */
export const validateLoginForm = (values) => ({
  email: validateEmail(values.email),
  password: validateRequired(values.password, "Password"),
});
