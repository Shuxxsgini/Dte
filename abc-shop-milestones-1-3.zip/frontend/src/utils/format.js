// Small helper to show prices nicely.

// The backend sends prices as text like "1000.00"; this shows "₹1,000.00"
const rupeeFormatter = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" });

/** @param {string|number} amount */
export const formatPrice = (amount) => rupeeFormatter.format(Number(amount));
