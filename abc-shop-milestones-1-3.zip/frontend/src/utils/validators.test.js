// Unit tests for the validation rules. Run with: npm test
import { describe, expect, it } from "vitest";
import {
  validateEmail,
  validateLoginForm,
  validateMobile,
  validateName,
  validatePassword,
  validateQuantity,
} from "./validators.js";

describe("validateName", () => {
  it("accepts letters and spaces, 6 or more characters", () => {
    expect(validateName("Rudra Joshi")).toBe("");
  });
  it("rejects empty, short, and non-letter names", () => {
    expect(validateName("")).toBe("Name is required.");
    expect(validateName("Rudra")).toBe("Name must be at least 6 characters.");
    expect(validateName("Rudra123")).toBe("Name can contain letters and spaces only.");
  });
});

describe("validateEmail", () => {
  it("accepts a normal email", () => {
    expect(validateEmail("rudra@abcshop.com")).toBe("");
  });
  it("rejects empty and badly formatted emails", () => {
    expect(validateEmail("")).toBe("Email is required.");
    expect(validateEmail("rudra@abcshop")).not.toBe("");
  });
});

describe("validatePassword", () => {
  it("accepts a strong password", () => {
    expect(validatePassword("Rudra@1234")).toBe("");
  });
  it("lists the first missing rule", () => {
    expect(validatePassword("short")).toBe("Password must be at least 8 characters.");
    expect(validatePassword("rudra@1234")).toBe("Add at least one uppercase letter.");
    expect(validatePassword("RUDRA@1234")).toBe("Add at least one lowercase letter.");
    expect(validatePassword("Rudra@abcd")).toBe("Add at least one number.");
    expect(validatePassword("Rudra12345")).toBe("Add at least one special character, like @ or #.");
  });
});

describe("validateMobile", () => {
  it("needs exactly 10 digits", () => {
    expect(validateMobile("9876543210")).toBe("");
    expect(validateMobile("98765")).not.toBe("");
    expect(validateMobile("98765abcde")).not.toBe("");
  });
});

describe("validateQuantity", () => {
  it("accepts a whole number within stock", () => {
    expect(validateQuantity("3", 5)).toBe("");
  });
  it("rejects zero, negatives, decimals, text, and too many", () => {
    expect(validateQuantity("0", 5)).not.toBe("");
    expect(validateQuantity("-1", 5)).not.toBe("");
    expect(validateQuantity("1.5", 5)).not.toBe("");
    expect(validateQuantity("abc", 5)).not.toBe("");
    expect(validateQuantity("6", 5)).toBe("Only 5 in stock.");
  });
});

describe("validateLoginForm", () => {
  it("only checks that the password is filled in (any password can log in)", () => {
    expect(validateLoginForm({ email: "rudra@abcshop.com", password: "rudra1234" })).toEqual({
      email: "",
      password: "",
    });
  });
});
