import { Route, Routes } from "react-router-dom";

import Header from "./components/layout/Header.jsx";
import Footer from "./components/layout/Footer.jsx";
import ProtectedRoute from "./components/common/ProtectedRoute.jsx";

import HomePage from "./pages/HomePage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import ProductListPage from "./pages/ProductListPage.jsx";
import ProductDetailsPage from "./pages/ProductDetailsPage.jsx";
import CartPage from "./pages/CartPage.jsx";
import ComingSoonPage from "./pages/ComingSoonPage.jsx";
import ProfilePage from "./pages/ProfilePage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";

// App = the page layout (Header, Main Content, Footer) + the list of pages.
// Header and Footer always show; only <main> changes with the URL.
function App() {
  return (
    <div className="d-flex flex-column min-vh-100">
      <Header />

      {/* Main Content area. flex-grow-1 = take all leftover space */}
      <main className="flex-grow-1 container py-4">
        <Routes>
          {/* Public pages: anyone can open them */}
          <Route path="/" element={<HomePage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/products" element={<ProductListPage />} />
          <Route path="/products/:productId" element={<ProductDetailsPage />} />

          {/* Protected pages: ProtectedRoute sends logged-out users to /login */}
          <Route path="/cart" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
          {/* Placeholders until Milestones 4 and 5 */}
          <Route path="/checkout" element={<ProtectedRoute><ComingSoonPage title="Checkout" milestone={5} /></ProtectedRoute>} />
          <Route path="/orders" element={<ProtectedRoute><ComingSoonPage title="My Orders" milestone={4} /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />

          {/* Any other URL */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;
