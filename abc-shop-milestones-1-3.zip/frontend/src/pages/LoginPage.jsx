import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

import FormInput from "../components/common/FormInput.jsx";
import AlertMessage from "../components/common/AlertMessage.jsx";
import { useForm } from "../hooks/useForm.js";
import { validateLoginForm } from "../utils/validators.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useCart } from "../context/CartContext.jsx";

const INITIAL_VALUES = { email: "", password: "" };

// Milestone 1: Login page with validations
function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { refreshCartCount } = useCart();

  const { values, isValid, handleChange, handleBlur, touchAll, reset, errorFor } = useForm(
    INITIAL_VALUES,
    validateLoginForm
  );
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  // Messages passed from other pages (e.g. after registering, or a protected page)
  const successMessage = location.state?.success ?? "";
  const infoMessage = location.state?.message ?? "";
  // Where to go after logging in: the page the user wanted, or the product list
  const redirectTo = location.state?.from ?? "/products";

  const handleSubmit = async (event) => {
    event.preventDefault();
    touchAll();
    if (!isValid) return;

    setSubmitting(true);
    setServerError("");
    try {
      await login(values.email.trim(), values.password);
      refreshCartCount();
      navigate(redirectTo, { replace: true });
    } catch (error) {
      // e.g. 401 "Invalid email or password."
      setServerError(error.message);
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    reset();
    setServerError("");
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-7 col-lg-5">
        <h1 className="h3 text-center mb-4">Login</h1>

        <AlertMessage type="success" message={successMessage} />
        <AlertMessage type="info" message={infoMessage} />
        <AlertMessage type="danger" message={serverError} />

        <form onSubmit={handleSubmit} noValidate>
          <FormInput
            label="Email address"
            name="email"
            type="email"
            value={values.email}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("email")}
            autoComplete="email"
          />
          <FormInput
            label="Password"
            name="password"
            type="password"
            value={values.password}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("password")}
            autoComplete="current-password"
          />

          <div className="d-flex gap-2">
            <button type="submit" className="btn btn-dark flex-grow-1" disabled={!isValid || submitting}>
              {submitting ? "Logging in..." : "Login"}
            </button>
            <button type="button" className="btn btn-outline-secondary" onClick={handleReset} disabled={submitting}>
              Reset
            </button>
          </div>
        </form>

        <p className="text-center small mt-3">
          Don&apos;t have an account? <Link to="/register">Register</Link>
        </p>
      </div>
    </div>
  );
}

export default LoginPage;
