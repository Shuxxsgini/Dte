import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext.jsx";

// Profile: the logged-in user's details (from GET /api/users/me)
function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-7 col-lg-5">
        <h1 className="h3 mb-4">My Profile</h1>

        <dl className="row">
          <dt className="col-4">Name</dt>
          <dd className="col-8">{user.name}</dd>
          <dt className="col-4">Email</dt>
          <dd className="col-8">{user.email}</dd>
          <dt className="col-4">Mobile</dt>
          <dd className="col-8">{user.mobile}</dd>
          <dt className="col-4">Role</dt>
          <dd className="col-8 text-capitalize">{user.role}</dd>
        </dl>

        <div className="d-flex gap-2">
          <Link to="/orders" className="btn btn-outline-dark">
            My orders
          </Link>
          <button type="button" className="btn btn-dark" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProfilePage;
