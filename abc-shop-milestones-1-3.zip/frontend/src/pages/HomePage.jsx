import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { getCategories } from "../services/productService.js";
import { useAuth } from "../context/AuthContext.jsx";

// Landing page: a welcome message and shortcuts to each category
function HomePage() {
  const { user } = useAuth();
  const [categories, setCategories] = useState([]);

  // Load the categories once, when the page opens ([] = run once)
  useEffect(() => {
    getCategories()
      .then((data) => setCategories(data))
      .catch(() => setCategories([])); // the shortcuts are optional, so just hide them
  }, []);

  return (
    <>
      <section className="p-4 p-md-5 mb-4 bg-light border rounded-3">
        <h1 className="display-6 fw-bold">{user ? `Welcome back, ${user.name}` : "Welcome to ABC Shop"}</h1>
        <p className="lead mb-4">Electronics, books, clothing, and home essentials, delivered to your door.</p>
        <Link to="/products" className="btn btn-dark btn-lg">
          Browse products
        </Link>
      </section>

      {categories.length > 0 && (
        <section>
          <h2 className="h5 mb-3">Shop by category</h2>
          <div className="d-flex flex-wrap gap-2">
            {categories.map((category) => (
              // encodeURIComponent makes "Home & Kitchen" safe to put in a URL
              <Link
                key={category.category_id}
                to={`/products?category=${encodeURIComponent(category.category_name)}`}
                className="btn btn-outline-dark"
              >
                {category.category_name}
              </Link>
            ))}
          </div>
        </section>
      )}
    </>
  );
}

export default HomePage;
