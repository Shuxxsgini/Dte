import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import CartItemRow from "../components/cart/CartItemRow.jsx";
import Loader from "../components/common/Loader.jsx";
import AlertMessage from "../components/common/AlertMessage.jsx";
import { getCartItems, getCartSummary, removeCartItem, updateCartItem } from "../services/cartService.js";
import { getAllProducts } from "../services/productService.js";
import { useCart } from "../context/CartContext.jsx";
import { formatPrice } from "../utils/format.js";

// Milestone 3: Cart management (view, update quantity, remove, total, checkout)
function CartPage() {
  const navigate = useNavigate();
  const { refreshCartCount } = useCart();

  const [items, setItems] = useState([]);
  const [summary, setSummary] = useState(null);
  const [stockById, setStockById] = useState({}); // { product_id: available_quantity }
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null); // cart item being updated/removed
  const [notice, setNotice] = useState({ type: "success", text: "" });

  // Load the cart, its totals, and current stock, all at the same time.
  // (Cart items don't include stock, so we read it from the product list.)
  const loadCart = useCallback(async () => {
    try {
      const [cartItems, cartSummary, products] = await Promise.all([
        getCartItems(),
        getCartSummary(),
        getAllProducts(),
      ]);

      const stock = {};
      products.forEach((product) => {
        stock[product.product_id] = product.available_quantity;
      });

      setItems(cartItems);
      setSummary(cartSummary);
      setStockById(stock);
    } catch (err) {
      setNotice({ type: "danger", text: err.message });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCart();
  }, [loadCart]);

  // After every change we reload, so the total updates automatically
  const handleUpdate = async (cartItemId, quantity) => {
    setBusyId(cartItemId);
    try {
      await updateCartItem(cartItemId, quantity);
      await loadCart();
      refreshCartCount();
      setNotice({ type: "success", text: "Quantity updated." });
    } catch (err) {
      setNotice({ type: "danger", text: err.message });
    } finally {
      setBusyId(null);
    }
  };

  const handleRemove = async (cartItemId) => {
    setBusyId(cartItemId);
    try {
      await removeCartItem(cartItemId);
      await loadCart();
      refreshCartCount();
      setNotice({ type: "success", text: "Item removed from your cart." });
    } catch (err) {
      setNotice({ type: "danger", text: err.message });
    } finally {
      setBusyId(null);
    }
  };

  if (loading) return <Loader text="Loading your cart..." />;

  // Products that were removed from the shop are missing from the list → stock 0
  const stockOf = (item) => stockById[item.product.product_id] ?? 0;
  const hasStockProblem = items.some((item) => item.quantity > stockOf(item));

  return (
    <>
      <h1 className="h3 mb-3">Your Cart</h1>

      <AlertMessage type={notice.type} message={notice.text} />

      {items.length === 0 ? (
        <div className="py-4">
          <p>Your cart is empty.</p>
          <Link to="/products" className="btn btn-dark">
            Browse products
          </Link>
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table align-middle">
              <thead>
                <tr>
                  <th scope="col">Product</th>
                  <th scope="col">Price</th>
                  <th scope="col">Qty</th>
                  <th scope="col">Subtotal</th>
                  <th scope="col">
                    <span className="visually-hidden">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <CartItemRow
                    key={item.cart_item_id}
                    item={item}
                    stock={stockOf(item)}
                    onUpdate={handleUpdate}
                    onRemove={handleRemove}
                    busy={busyId === item.cart_item_id}
                  />
                ))}
              </tbody>
            </table>
          </div>

          <AlertMessage
            type="warning"
            message={hasStockProblem ? "Some items have more than the stock available. Lower the quantity or remove them to check out." : ""}
          />

          <div className="d-flex flex-column align-items-end gap-2">
            <p className="mb-0 text-secondary">
              {summary.total_quantity} item{summary.total_quantity === 1 ? "" : "s"}
            </p>
            <p className="fs-5 fw-bold mb-0">Total: {formatPrice(summary.total_amount)}</p>
            {/* Enabled only if the cart isn't empty (and stock is OK) */}
            <button
              type="button"
              className="btn btn-dark"
              disabled={items.length === 0 || hasStockProblem}
              onClick={() => navigate("/checkout")}
            >
              Checkout
            </button>
          </div>
        </>
      )}
    </>
  );
}

export default CartPage;
