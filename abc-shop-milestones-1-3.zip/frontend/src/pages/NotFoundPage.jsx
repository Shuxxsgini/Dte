import { Link } from "react-router-dom";

// Shown for any URL that doesn't match a page
function NotFoundPage() {
  return (
    <div className="text-center py-5">
      <h1 className="h3">Page not found</h1>
      <p className="text-secondary">The page you&apos;re looking for doesn&apos;t exist.</p>
      <Link to="/" className="btn btn-dark">
        Go to the home page
      </Link>
    </div>
  );
}

export default NotFoundPage;
