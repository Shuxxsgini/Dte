import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import ProductImage from "../components/products/ProductImage.jsx";
import Loader from "../components/common/Loader.jsx";
import AlertMessage from "../components/common/AlertMessage.jsx";
import { getProductById } from "../services/productService.js";
import { addToCart } from "../services/cartService.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useCart } from "../context/CartContext.jsx";
import { validateQuantity } from "../utils/validators.js";
import { formatPrice } from "../utils/format.js";

// Milestone 2: Product details (one product, choose a quantity, add to cart)
function ProductDetailsPage() {
  const { productId } = useParams(); // the ":productId" part of the URL
  const navigate = useNavigate();
  const { isLoggedIn } = useAuth();
  const { refreshCartCount } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [adding, setAdding] = useState(false);
  const [notice, setNotice] = useState({ type: "success", text: "" });

  // Load the product whenever the ID in the URL changes
  useEffect(() => {
    let ignore = false;
    getProductById(productId)
      .then((data) => {
        if (!ignore) setProduct(data);
      })
      .catch((err) => {
        if (!ignore) setError(err.status === 404 ? "Product not found." : err.message);
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, [productId]);

  if (loading) return <Loader text="Loading product..." />;

  if (error) {
    return (
      <>
        <AlertMessage type="danger" message={error} />
        <Link to="/products">Back to products</Link>
      </>
    );
  }

  const inStock = product.available_quantity > 0;
  const quantityError = inStock ? validateQuantity(quantity, product.available_quantity) : "";

  const handleAddToCart = async () => {
    if (!isLoggedIn) {
      navigate("/login", {
        state: { from: `/products/${productId}`, message: "Please log in to add items to your cart." },
      });
      return;
    }

    setAdding(true);
    try {
      await addToCart(product.product_id, Number(quantity));
      refreshCartCount();
      setNotice({ type: "success", text: `Added ${quantity} × ${product.product_name} to your cart.` });
    } catch (err) {
      setNotice({ type: "danger", text: err.message });
    } finally {
      setAdding(false);
    }
  };

  return (
    <>
      <Link to="/products" className="d-inline-block mb-3">
        <i className="bi bi-arrow-left me-1"></i>Back to products
      </Link>

      <AlertMessage type={notice.type} message={notice.text} />

      <div className="row g-4">
        <div className="col-md-5">
          <div className="border rounded overflow-hidden">
            <ProductImage url={product.product_url} name={product.product_name} categoryName={product.category.category_name} />
          </div>
        </div>

        <div className="col-md-7">
          <span className="badge text-bg-light border mb-2">{product.category.category_name}</span>
          <h1 className="h3">{product.product_name}</h1>
          <p className="fs-4 fw-semibold">{formatPrice(product.price)}</p>
          <p>{product.description || "No description available."}</p>
          <p className={inStock ? "text-success" : "text-danger"}>
            {inStock ? `In stock: ${product.available_quantity}` : "Out of Stock"}
          </p>

          {inStock && (
            <div className="d-flex align-items-start gap-2">
              <div>
                <label htmlFor="detail-quantity" className="visually-hidden">
                  Quantity
                </label>
                <input
                  id="detail-quantity"
                  type="number"
                  min="1"
                  max={product.available_quantity}
                  className={`form-control quantity-input ${quantityError ? "is-invalid" : ""}`}
                  value={quantity}
                  onChange={(event) => setQuantity(event.target.value)}
                />
                {quantityError && <div className="invalid-feedback d-block small">{quantityError}</div>}
              </div>
              <button
                type="button"
                className="btn btn-dark"
                disabled={Boolean(quantityError) || adding}
                onClick={handleAddToCart}
              >
                {adding ? "Adding..." : "Add to Cart"}
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default ProductDetailsPage;
