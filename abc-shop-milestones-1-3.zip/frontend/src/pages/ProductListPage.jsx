import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

import SearchBar from "../components/products/SearchBar.jsx";
import ProductCard from "../components/products/ProductCard.jsx";
import Loader from "../components/common/Loader.jsx";
import AlertMessage from "../components/common/AlertMessage.jsx";
import { getCategories, searchProducts } from "../services/productService.js";
import { addToCart } from "../services/cartService.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useCart } from "../context/CartContext.jsx";

// Milestone 2: Product listing with search by name and category
function ProductListPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { isLoggedIn } = useAuth();
  const { refreshCartCount } = useCart();

  const [searchText, setSearchText] = useState("");
  // Start with the category from the URL, e.g. /products?category=Books
  const [category, setCategory] = useState(searchParams.get("category") ?? "");
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState({ type: "success", text: "" }); // add-to-cart result
  const [addingId, setAddingId] = useState(null); // product being added right now

  // Load the categories for the dropdown, once
  useEffect(() => {
    getCategories()
      .then((data) => setCategories(data))
      .catch(() => setCategories([]));
  }, []);

  // Search as the user types: wait 300 ms after the last key press,
  // then call GET /api/products/search?name=...&category=...
  useEffect(() => {
    let ignore = false; // becomes true if a newer search starts

    const timerId = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await searchProducts(searchText, category);
        if (!ignore) {
          setProducts(data);
          setError("");
        }
      } catch (err) {
        if (!ignore) setError(err.message);
      } finally {
        if (!ignore) setLoading(false);
      }
    }, 300);

    // Cleanup: runs before the next search. Cancels the old timer and
    // ignores an old answer that arrives late.
    return () => {
      ignore = true;
      clearTimeout(timerId);
    };
  }, [searchText, category]);

  const handleAddToCart = async (product) => {
    // The cart needs a login: send the user to Login, then bring them back here
    if (!isLoggedIn) {
      navigate("/login", { state: { from: "/products", message: "Please log in to add items to your cart." } });
      return;
    }

    setAddingId(product.product_id);
    try {
      await addToCart(product.product_id, 1);
      refreshCartCount();
      setNotice({ type: "success", text: `${product.product_name} was added to your cart.` });
    } catch (err) {
      // e.g. "Only 5 'Apron' in stock." when the cart already holds them all
      setNotice({ type: "danger", text: err.message });
    } finally {
      setAddingId(null);
    }
  };

  return (
    <>
      <h1 className="h3 mb-3">Products</h1>

      <SearchBar
        searchText={searchText}
        onSearchTextChange={setSearchText}
        category={category}
        onCategoryChange={setCategory}
        categories={categories}
      />

      <AlertMessage type={notice.type} message={notice.text} />
      <AlertMessage type="danger" message={error} />

      {loading ? (
        <Loader text="Loading products..." />
      ) : products.length === 0 ? (
        !error && <p className="text-secondary">No products match your search.</p>
      ) : (
        // Grid: 1 card per row on phones, 2 on tablets, 3 on laptops
        <div className="row row-cols-1 row-cols-sm-2 row-cols-lg-3 g-4">
          {products.map((product) => (
            <div className="col" key={product.product_id}>
              <ProductCard
                product={product}
                onAddToCart={handleAddToCart}
                adding={addingId === product.product_id}
              />
            </div>
          ))}
        </div>
      )}
    </>
  );
}

export default ProductListPage;
