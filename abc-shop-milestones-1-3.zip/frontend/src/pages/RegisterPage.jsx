import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import FormInput from "../components/common/FormInput.jsx";
import AlertMessage from "../components/common/AlertMessage.jsx";
import { useForm } from "../hooks/useForm.js";
import { validateRegisterForm } from "../utils/validators.js";
import { registerUser } from "../services/authService.js";

// Blank form. Mobile is included because the backend requires it.
const INITIAL_VALUES = { name: "", email: "", mobile: "", password: "" };

// Milestone 1: Registration page with validations
function RegisterPage() {
  const navigate = useNavigate();
  const { values, isValid, handleChange, handleBlur, touchAll, reset, errorFor } = useForm(
    INITIAL_VALUES,
    validateRegisterForm
  );
  const [submitting, setSubmitting] = useState(false); // true while the request runs
  const [serverError, setServerError] = useState(""); // message from the backend

  const handleSubmit = async (event) => {
    event.preventDefault(); // stop the browser from reloading the page
    touchAll(); // show every field's error
    if (!isValid) return; // prevent registration if validation fails

    setSubmitting(true);
    setServerError("");
    try {
      await registerUser({
        name: values.name.trim(),
        email: values.email.trim(),
        mobile: values.mobile.trim(),
        password: values.password,
      });
      // Success: go to Login with a green message
      navigate("/login", { state: { success: "Registration successful. Please log in." } });
    } catch (error) {
      // e.g. 409 "Email is already Registered." (the email uniqueness check)
      setServerError(error.message);
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    reset(); // all fields back to blank
    setServerError("");
  };

  return (
    <div className="row justify-content-center">
      <div className="col-md-7 col-lg-5">
        <h1 className="h3 text-center mb-4">Register</h1>

        <AlertMessage type="danger" message={serverError} />

        {/* noValidate: we show our own messages instead of the browser's */}
        <form onSubmit={handleSubmit} noValidate>
          <FormInput
            label="Full Name"
            name="name"
            value={values.name}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("name")}
            autoComplete="name"
          />
          <FormInput
            label="Email address"
            name="email"
            type="email"
            value={values.email}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("email")}
            autoComplete="email"
          />
          <FormInput
            label="Mobile number"
            name="mobile"
            type="tel"
            value={values.mobile}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("mobile")}
            hint="10 digits, e.g. 9876543210"
            autoComplete="tel"
          />
          <FormInput
            label="Password"
            name="password"
            type="password"
            value={values.password}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errorFor("password")}
            hint="8–25 characters with an uppercase letter, a lowercase letter, a number, and a special character."
            autoComplete="new-password"
          />

          <div className="d-flex gap-2">
            {/* Enabled only when every field is valid, disabled while the request runs */}
            <button type="submit" className="btn btn-dark flex-grow-1" disabled={!isValid || submitting}>
              {submitting ? "Registering..." : "Register"}
            </button>
            <button type="button" className="btn btn-outline-secondary" onClick={handleReset} disabled={submitting}>
              Reset
            </button>
          </div>
        </form>

        <p className="text-center small mt-3">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}

export default RegisterPage;
