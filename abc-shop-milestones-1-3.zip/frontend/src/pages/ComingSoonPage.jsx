import { Link } from "react-router-dom";
import PropTypes from "prop-types";

// Temporary page for parts we build in later milestones (Checkout, Orders)
function ComingSoonPage({ title, milestone }) {
  return (
    <div className="text-center py-5">
      <h1 className="h3">{title}</h1>
      <p className="text-secondary">This page is built in Milestone {milestone}.</p>
      <Link to="/products" className="btn btn-dark">
        Continue shopping
      </Link>
    </div>
  );
}

ComingSoonPage.propTypes = {
  title: PropTypes.string.isRequired,
  milestone: PropTypes.number.isRequired,
};

export default ComingSoonPage;
