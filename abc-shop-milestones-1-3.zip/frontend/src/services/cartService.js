// Calls for the logged-in user's cart. All of them need the token (auth: true).
import { apiRequest } from "./apiClient.js";

/** Cart items: [{ cart_item_id, quantity, product: { product_id, product_name, price } }] */
export const getCartItems = () => apiRequest("/api/cart", { auth: true });

/** Totals: { total_items, total_quantity, total_amount } */
export const getCartSummary = () => apiRequest("/api/cart/summary", { auth: true });

/**
 * Add a product to the cart (adds to the quantity if it's already there).
 * @param {number} productId
 * @param {number} quantity
 */
export const addToCart = (productId, quantity) =>
  apiRequest("/api/cart/add", { method: "POST", body: { product_id: productId, quantity }, auth: true });

/**
 * Change the quantity of one cart item.
 * @param {number} cartItemId
 * @param {number} quantity
 */
export const updateCartItem = (cartItemId, quantity) =>
  apiRequest(`/api/cart/update/${cartItemId}`, { method: "PUT", body: { quantity }, auth: true });

/**
 * Remove one item from the cart.
 * @param {number} cartItemId
 */
export const removeCartItem = (cartItemId) =>
  apiRequest(`/api/cart/remove/${cartItemId}`, { method: "DELETE", auth: true });
