// Calls for registration, login, and "who am I".
import { apiRequest } from "./apiClient.js";

/**
 * Create a new account.
 * @param {{name: string, email: string, mobile: string, password: string}} userData
 */
export const registerUser = (userData) =>
  apiRequest("/api/users/register", { method: "POST", body: userData });

/**
 * Log in. Returns { access_token, token_type }.
 * @param {string} email
 * @param {string} password
 */
export const loginUser = (email, password) =>
  apiRequest("/api/auth/login", { method: "POST", body: { email, password } });

/** The logged-in user's details: { user_id, name, email, mobile, role } */
export const getCurrentUser = () => apiRequest("/api/users/me", { auth: true });
