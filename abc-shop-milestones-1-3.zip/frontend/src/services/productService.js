// Calls for products and categories (public, no login needed).
import { apiRequest } from "./apiClient.js";

/** All categories: [{ category_id, category_name }] */
export const getCategories = () => apiRequest("/api/categories");

/** All active products */
export const getAllProducts = () => apiRequest("/api/products");

/**
 * One product by its ID.
 * @param {number|string} productId
 */
export const getProductById = (productId) => apiRequest(`/api/products/${productId}`);

/**
 * Search products by name and/or category.
 * Empty values are left out, so an empty search returns every product.
 * @param {string} [name] - part of the product name
 * @param {string} [category] - exact category name, e.g. "Books"
 */
export const searchProducts = (name = "", category = "") => {
  // URLSearchParams builds "?name=jeans&category=Clothing" and encodes
  // special characters safely (e.g. the "&" in "Home & Kitchen")
  const params = new URLSearchParams();
  if (name.trim()) params.append("name", name.trim());
  if (category) params.append("category", category);

  const query = params.toString();
  return apiRequest(`/api/products/search${query ? `?${query}` : ""}`);
};
