// One place to save, read, and delete the login token (JWT).
// localStorage keeps the token after a page refresh, so the user stays logged in.
// (The token expires after 30 minutes on the backend anyway.)
const TOKEN_KEY = "abc_shop_token";

export const saveToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);
