// Entry point: React starts here and draws <App /> inside
// the <div id="root"> in index.html.
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";

// Load Bootstrap styles and icons once, for the whole app
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./index.css";

import App from "./App.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { CartProvider } from "./context/CartContext.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    {/* BrowserRouter: lets the app use URLs like /login and /cart */}
    <BrowserRouter>
      {/* AuthProvider: shares "who is logged in" with every page */}
      <AuthProvider>
        {/* CartProvider: shares the cart item count (for the header badge) */}
        <CartProvider>
          <App />
        </CartProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>
);
