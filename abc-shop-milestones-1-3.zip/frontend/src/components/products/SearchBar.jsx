import PropTypes from "prop-types";

// Search box (product name) + category dropdown, shown above the product list
function SearchBar({ searchText, onSearchTextChange, category, onCategoryChange, categories }) {
  return (
    <div className="row g-2 mb-4">
      <div className="col-md-8">
        <label htmlFor="product-search" className="visually-hidden">
          Search products by name
        </label>
        <div className="input-group">
          <span className="input-group-text">
            <i className="bi bi-search"></i>
          </span>
          <input
            id="product-search"
            type="search"
            className="form-control"
            placeholder="Search products by name..."
            value={searchText}
            onChange={(event) => onSearchTextChange(event.target.value)}
          />
        </div>
      </div>

      <div className="col-md-4">
        <label htmlFor="category-filter" className="visually-hidden">
          Filter by category
        </label>
        <select
          id="category-filter"
          className="form-select"
          value={category}
          onChange={(event) => onCategoryChange(event.target.value)}
        >
          <option value="">All categories</option>
          {categories.map((item) => (
            <option key={item.category_id} value={item.category_name}>
              {item.category_name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

SearchBar.propTypes = {
  searchText: PropTypes.string.isRequired,
  onSearchTextChange: PropTypes.func.isRequired,
  category: PropTypes.string.isRequired,
  onCategoryChange: PropTypes.func.isRequired,
  categories: PropTypes.arrayOf(
    PropTypes.shape({
      category_id: PropTypes.number.isRequired,
      category_name: PropTypes.string.isRequired,
    })
  ).isRequired,
};

export default SearchBar;
