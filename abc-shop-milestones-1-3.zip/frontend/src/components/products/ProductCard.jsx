import { Link } from "react-router-dom";
import PropTypes from "prop-types";

import ProductImage from "./ProductImage.jsx";
import { formatPrice } from "../../utils/format.js";

// One product in the grid: picture, name, category, price, stock, Add to Cart
function ProductCard({ product, onAddToCart, adding = false }) {
  const inStock = product.available_quantity > 0;

  return (
    <div className="card h-100">
      <ProductImage url={product.product_url} name={product.product_name} categoryName={product.category.category_name} />

      <div className="card-body d-flex flex-column">
        <h2 className="h6 card-title mb-1">
          <Link to={`/products/${product.product_id}`} className="text-dark">
            {product.product_name}
          </Link>
        </h2>
        <span className="badge text-bg-light border align-self-start mb-2">{product.category.category_name}</span>

        {/* "No fields left blank": show a fallback when there's no description */}
        <p className="card-text small text-secondary">{product.description || "No description available."}</p>

        <div className="mt-auto">
          <p className="fw-semibold mb-1">{formatPrice(product.price)}</p>
          <p className={`small mb-2 ${inStock ? "text-success" : "text-danger"}`}>
            {inStock ? `In stock: ${product.available_quantity}` : "Out of Stock"}
          </p>

          {/* Enabled only if the product is in stock (and not already being added) */}
          <button
            type="button"
            className="btn btn-dark w-100"
            disabled={!inStock || adding}
            onClick={() => onAddToCart(product)}
          >
            {!inStock ? "Out of Stock" : adding ? "Adding..." : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  );
}

// The shape of a product object from the backend
const productShape = PropTypes.shape({
  product_id: PropTypes.number.isRequired,
  product_name: PropTypes.string.isRequired,
  description: PropTypes.string,
  price: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  available_quantity: PropTypes.number.isRequired,
  product_url: PropTypes.string,
  category: PropTypes.shape({
    category_id: PropTypes.number.isRequired,
    category_name: PropTypes.string.isRequired,
  }).isRequired,
});

ProductCard.propTypes = {
  product: productShape.isRequired,
  onAddToCart: PropTypes.func.isRequired,
  adding: PropTypes.bool,
};

export default ProductCard;
