import PropTypes from "prop-types";

// Only treat a URL as a picture if it ends like an image file
const IMAGE_URL_PATTERN = /\.(jpg|jpeg|png|webp|gif)(\?.*)?$/i;

// An icon for each seeded category, used when a product has no picture
const CATEGORY_ICONS = {
  Electronics: "bi-headphones",
  Books: "bi-book",
  Clothing: "bi-handbag",
  "Home & Kitchen": "bi-cup-hot",
};

// Shows the product's picture, or a grey box with a category icon instead
function ProductImage({ url = null, name, categoryName }) {
  if (url && IMAGE_URL_PATTERN.test(url)) {
    return <img src={url} alt={name} className="card-img-top product-image p-3" />;
  }

  const iconClass = CATEGORY_ICONS[categoryName] ?? "bi-bag";
  return (
    <div className="product-placeholder bg-light d-flex align-items-center justify-content-center text-secondary" aria-hidden="true">
      <i className={`bi ${iconClass}`}></i>
    </div>
  );
}

ProductImage.propTypes = {
  url: PropTypes.string,
  name: PropTypes.string.isRequired,
  categoryName: PropTypes.string.isRequired,
};

export default ProductImage;
