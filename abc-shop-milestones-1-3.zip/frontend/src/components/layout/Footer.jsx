import { Link } from "react-router-dom";

// Footer: about text, quick links, contact details, and copyright
function Footer() {
  // The year updates by itself every year
  const currentYear = new Date().getFullYear();

  return (
    // mt-auto pushes the footer to the bottom of the page
    <footer className="bg-dark text-light mt-auto">
      <div className="container py-4">
        <div className="row">
          {/* col-md-3 = 4 columns side by side on laptops, stacked on phones */}
          <div className="col-md-3 mb-3">
            <h5>ABC SHOP</h5>
            <p className="small mb-0">Your Own Shubhangini&apos;s Stop</p>
          </div>

          <div className="col-md-3 mb-3">
            <h6>Shop</h6>
            <ul className="list-unstyled small mb-0">
              <li><Link to="/products" className="footer-link">All Products</Link></li>
              <li><Link to="/cart" className="footer-link">My Cart</Link></li>
            </ul>
          </div>

          <div className="col-md-3 mb-3">
            <h6>Customer Service</h6>
            <ul className="list-unstyled small mb-0">
              <li><Link to="/orders" className="footer-link">My Orders</Link></li>
              <li><Link to="/profile" className="footer-link">My Account</Link></li>
            </ul>
          </div>

          <div className="col-md-3 mb-3">
            <h6>Contact Us</h6>
            <p className="small mb-1">
              <i className="bi bi-envelope me-2"></i>support@abcshop.com
            </p>
            <p className="small mb-0">
              <i className="bi bi-telephone me-2"></i>+91 98765 43210
            </p>
          </div>
        </div>

        <hr className="border-secondary" />
        <p className="small text-center mb-0">© {currentYear} ABC Shop. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
