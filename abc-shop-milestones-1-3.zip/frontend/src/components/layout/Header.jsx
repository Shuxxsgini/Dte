import { Link, useNavigate } from "react-router-dom";

import Menu from "./Menu.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useCart } from "../../context/CartContext.jsx";

// Header: brand name, menu, and the user area (cart, profile, login/logout)
function Header() {
  const { user, isLoggedIn, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="border-bottom bg-white">
      {/* flex-wrap lets items move to a new line on small screens */}
      <div className="container d-flex flex-wrap align-items-center justify-content-between gap-2 py-2">
        <Link to="/" className="fw-bold fs-4 text-dark text-decoration-none">
          ABC SHOP
        </Link>

        <Menu />

        <div className="d-flex align-items-center gap-2">
          {isLoggedIn ? (
            // Shown when logged in
            <>
              <Link to="/cart" className="btn btn-outline-dark position-relative" aria-label={`Cart, ${cartCount} items`}>
                <i className="bi bi-cart3"></i>
                {/* Red badge with the number of items, only if the cart isn't empty */}
                {cartCount > 0 && (
                  <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    {cartCount}
                  </span>
                )}
              </Link>
              <Link to="/profile" className="text-dark text-decoration-none d-flex align-items-center gap-1" title="My profile">
                <i className="bi bi-person-circle fs-4"></i>
                <span className="d-none d-md-inline">{user.name}</span>
              </Link>
              <button type="button" className="btn btn-dark btn-sm" onClick={handleLogout}>
                Logout
              </button>
            </>
          ) : (
            // Shown when logged out
            <>
              <Link to="/login" className="btn btn-outline-dark btn-sm">
                Login
              </Link>
              <Link to="/register" className="btn btn-dark btn-sm">
                Register
              </Link>
              <Link to="/login" className="text-dark fs-4" aria-label="Profile">
                <i className="bi bi-person-circle"></i>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;
