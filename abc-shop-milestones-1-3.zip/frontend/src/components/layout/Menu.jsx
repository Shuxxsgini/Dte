import { NavLink } from "react-router-dom";

// All menu links in one list. To add a page later, add one line here.
const MENU_LINKS = [
  { path: "/", label: "Home" },
  { path: "/products", label: "Products" },
  { path: "/cart", label: "Cart" },
  { path: "/orders", label: "My Orders" },
];

// Menu: links to the main sections of the app
function Menu() {
  return (
    <nav aria-label="Main menu">
      <ul className="nav">
        {/* .map() turns each item of the list into a <li> */}
        {MENU_LINKS.map((link) => (
          <li className="nav-item" key={link.path}>
            {/* NavLink switches pages without reloading and adds the
                "active" class to the link of the page we're on */}
            <NavLink to={link.path} end={link.path === "/"} className="nav-link text-dark">
              {link.label}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export default Menu;
