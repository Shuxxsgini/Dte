import { Navigate, useLocation } from "react-router-dom";
import PropTypes from "prop-types";

import Loader from "./Loader.jsx";
import { useAuth } from "../../context/AuthContext.jsx";

/**
 * Wraps pages that need a login (cart, checkout, orders, profile).
 * Logged out → send to /login, remembering where the user wanted to go.
 */
function ProtectedRoute({ children }) {
  const { isLoggedIn, loading } = useAuth();
  const location = useLocation();

  // Still checking a saved token: wait instead of redirecting too early
  if (loading) return <Loader text="Checking your login..." />;

  if (!isLoggedIn) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname, message: "Please log in to continue." }}
      />
    );
  }

  return children;
}

ProtectedRoute.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ProtectedRoute;
