import PropTypes from "prop-types";

/**
 * Reusable form field: label + input + error message.
 * Used by the Register and Login forms.
 */
function FormInput({ label, name, type = "text", value, onChange, onBlur, error = "", hint = "", autoComplete = "off" }) {
  const inputId = `field-${name}`;

  return (
    <div className="mb-3">
      <label htmlFor={inputId} className="form-label">
        {label}
      </label>
      <input
        id={inputId}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        autoComplete={autoComplete}
        // "is-invalid" turns the box red (Bootstrap)
        className={`form-control ${error ? "is-invalid" : ""}`}
        aria-invalid={Boolean(error)}
        aria-describedby={`${inputId}-message`}
      />
      {/* Show the error if there is one, otherwise the hint (if any) */}
      {error ? (
        <div id={`${inputId}-message`} className="invalid-feedback">
          {error}
        </div>
      ) : (
        hint && (
          <div id={`${inputId}-message`} className="form-text">
            {hint}
          </div>
        )
      )}
    </div>
  );
}

// PropTypes: the data type each prop must have.
// React shows a warning in the console if a wrong type is passed.
FormInput.propTypes = {
  label: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  type: PropTypes.oneOf(["text", "email", "password", "tel", "number"]),
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  onBlur: PropTypes.func.isRequired,
  error: PropTypes.string,
  hint: PropTypes.string,
  autoComplete: PropTypes.string,
};

export default FormInput;
