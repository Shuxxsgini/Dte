import PropTypes from "prop-types";

// A coloured message box (Bootstrap alert). Shows nothing if there's no message.
function AlertMessage({ type = "danger", message = "" }) {
  if (!message) return null;

  return (
    <div className={`alert alert-${type}`} role="alert">
      {message}
    </div>
  );
}

AlertMessage.propTypes = {
  type: PropTypes.oneOf(["success", "danger", "warning", "info"]),
  message: PropTypes.string,
};

export default AlertMessage;
