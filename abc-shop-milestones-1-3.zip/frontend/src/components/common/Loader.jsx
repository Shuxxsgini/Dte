import PropTypes from "prop-types";

// A spinning circle shown while data is loading
function Loader({ text = "Loading..." }) {
  return (
    <div className="d-flex align-items-center gap-2 py-4 text-secondary">
      <div className="spinner-border spinner-border-sm" aria-hidden="true"></div>
      <span>{text}</span>
    </div>
  );
}

Loader.propTypes = {
  text: PropTypes.string,
};

export default Loader;
