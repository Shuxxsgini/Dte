import { useState } from "react";
import PropTypes from "prop-types";

import { validateQuantity } from "../../utils/validators.js";
import { formatPrice } from "../../utils/format.js";

/**
 * One row of the cart table: product, price, quantity box, subtotal, buttons.
 * The quantity is checked before the Update button can be used.
 */
function CartItemRow({ item, stock, onUpdate, onRemove, busy = false }) {
  // What the user types in the quantity box (kept as text while typing)
  const [quantity, setQuantity] = useState(String(item.quantity));

  const error = validateQuantity(quantity, stock);
  const changed = Number(quantity) !== item.quantity;
  const subtotal = Number(item.product.price) * item.quantity;
  const quantityId = `quantity-${item.cart_item_id}`;

  return (
    <tr>
      <td>
        <div className="fw-semibold">{item.product.product_name}</div>
        {stock === 0 && <div className="small text-danger">No longer available</div>}
      </td>
      <td>{formatPrice(item.product.price)}</td>
      <td>
        <label htmlFor={quantityId} className="visually-hidden">
          Quantity of {item.product.product_name}
        </label>
        <input
          id={quantityId}
          type="number"
          min="1"
          max={stock}
          className={`form-control form-control-sm quantity-input ${error ? "is-invalid" : ""}`}
          value={quantity}
          onChange={(event) => setQuantity(event.target.value)}
          disabled={busy}
        />
        {error && <div className="invalid-feedback d-block small">{error}</div>}
      </td>
      <td>{formatPrice(subtotal)}</td>
      <td className="text-nowrap">
        {/* Update: only when the new quantity is valid and different */}
        <button
          type="button"
          className="btn btn-outline-dark btn-sm me-2"
          disabled={Boolean(error) || !changed || busy}
          onClick={() => onUpdate(item.cart_item_id, Number(quantity))}
        >
          Update
        </button>
        <button
          type="button"
          className="btn btn-outline-danger btn-sm"
          disabled={busy}
          onClick={() => onRemove(item.cart_item_id)}
        >
          Remove
        </button>
      </td>
    </tr>
  );
}

CartItemRow.propTypes = {
  item: PropTypes.shape({
    cart_item_id: PropTypes.number.isRequired,
    quantity: PropTypes.number.isRequired,
    product: PropTypes.shape({
      product_id: PropTypes.number.isRequired,
      product_name: PropTypes.string.isRequired,
      price: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    }).isRequired,
  }).isRequired,
  stock: PropTypes.number.isRequired,
  onUpdate: PropTypes.func.isRequired,
  onRemove: PropTypes.func.isRequired,
  busy: PropTypes.bool,
};

export default CartItemRow;
